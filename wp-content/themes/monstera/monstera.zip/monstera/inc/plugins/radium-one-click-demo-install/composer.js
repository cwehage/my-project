{
    "name": "FrankM1/radium-one-click-demo-install",
    "description": "Once Click Demo Content Install for WordPress.",
    "license": "MIT",
    "authors": [
        {
            "name": "Frank Gitonga",
            "email": "frank@radiumthemes.com"
        },
        {
            "name": "Primoz Cigler",
            "email": "primoz@proteusnet.com"
        }
    ],
    "autoload": {
        "files": ["importer/radium-importer.php"]
    }
}